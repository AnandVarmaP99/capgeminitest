﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using WebAPI.Model;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PremiumDetController : ControllerBase
    {
        static List<PremiumDetails> premiumUserList = new();

        static List<Occupation> occupationsList = new List<Occupation>
        {
            new Occupation(){occType="doctor",rateType="professional" },
            new Occupation(){occType="cleaner",rateType="light manual" },
            new Occupation(){occType="author",rateType="white collar" },
            new Occupation(){occType="farmer",rateType="heavy manual" },
            new Occupation(){occType="mechanic",rateType="heavy manual" },
            new Occupation(){occType="florist",rateType="light manual" },
            new Occupation(){occType="other",rateType="heavy manual" }
        };

        static List<Rating> rateTypeList = new List<Rating>
        {
            new Rating(){rateType="professional",factor=1.5M },
            new Rating(){rateType="light manual",factor=11.5M },
            new Rating(){rateType="white collar",factor=2.25M },
            new Rating(){rateType="heavy manual",factor=31.75M }
        };


        [HttpGet]
        [Route("getall")]
        public IActionResult GetAddedPremiums()
        {
            //fetch products from db
            return StatusCode(StatusCodes.Status200OK, premiumUserList);
        }
        [NonAction]
        public decimal GetRateFactor(string occupation)
        {
            string rateType = occupationsList.Where(x => x.occType == occupation.ToLower()).Select(x => x.rateType).FirstOrDefault();
            decimal rateFactor = rateTypeList.Where(x => x.rateType == rateType).Select(x => x.factor).FirstOrDefault();

            return rateFactor;
        }

        [HttpPost]
        [Route("add")]
        public IActionResult AddPremium([FromBody] PremiumDetails custToAdd)
        {
            decimal factor = GetRateFactor(custToAdd.usualOccupation);
            custToAdd.monthlyPremium = (((custToAdd.sumInsured * factor) * custToAdd.ageAfterNextBirthday)/1000) * 12;
            premiumUserList.Add(custToAdd);
            return StatusCode(StatusCodes.Status201Created, true);
        }

       
    }
}
