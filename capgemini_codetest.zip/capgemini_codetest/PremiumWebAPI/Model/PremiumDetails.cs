﻿namespace WebAPI.Model
{
    public class PremiumDetails
    {
        public string? memberName { get; set; }
        public  DateTime dob { get; set; }
        public  int? ageAfterNextBirthday { get; set; }
        public  string? usualOccupation { get; set; }
        public decimal? sumInsured { get; set; }
        public decimal? monthlyPremium { get; set; }
    }

    public class Occupation
    {
        public string occType { get; set; }
        public string rateType { get; set; }
    }

    public class Rating
    {
        public string rateType {  get; set; }
        public decimal factor { get; set; }
    }

}
