import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { Product } from '../../models/product';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-product-list',
  imports: [CommonModule],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit,OnDestroy {
  productList!: Product[];
  productService = inject(ProductService);
  router=inject(Router);
  subscriptions:Subscription[];

  constructor() {
    this.subscriptions = [];
  }

  ngOnInit(): void {
    // this.productService.getProducts().subscribe({
    //   next: (resp) => {
    //     this.productList = resp;
    //   },
    //   complete: () => {
    //     console.log("Products as loaded");
    //   }
    // })
    this.loadProducts();
  }
  ngOnDestroy(): void {
    this.subscriptions.forEach(s=>s.unsubscribe());
    console.log('unsubscribed in destroy');
  }

  deleteProduct(productToRemove: Product) {
    let confirmDelete: boolean = confirm(`Do you wish to delete ${productToRemove.productName}?`);
    if (confirmDelete) {
      // this.productService.deleteProduct(productToRemove.productId ?? 0).subscribe({
      //   next: (res) => {
      //     alert('Product deleted Successfully');
      //     //this.loadProducts();
      //     this.productList=this.productList.filter(x=>x.productId!=productToRemove.productId);
      //   }
      // })

      this.subscriptions.push(
        this.productService.deleteProduct(productToRemove.productId ?? 0).subscribe({
        next: (res) => {
          alert('Product deleted Successfully');
          //this.loadProducts();
          this.productList=this.productList.filter(x=>x.productId!=productToRemove.productId);
        }
      })
      )

    }
  }
  private loadProducts()
  {
    //  this.productService.getProducts().subscribe({
    //   next: (resp) => {
    //     this.productList = resp;
    //   },
    //   complete: () => {
    //     console.log("Products as loaded");
    //   }
    // })
    this.subscriptions.push(
      this.productService.getProducts().subscribe({
      next: (resp) => {
        this.productList = resp;
      },
      complete: () => {
        console.log("Products as loaded");
      }
    })
    )
  }

  editProduct(id:number)
  {
    return this.router.navigate(['templatedrivenform'],{queryParams:{pid:id}});
  }
}
