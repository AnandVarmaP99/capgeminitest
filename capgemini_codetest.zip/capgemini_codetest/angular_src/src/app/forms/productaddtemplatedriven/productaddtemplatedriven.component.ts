import { Component, Inject, inject } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Product } from '../../models/product';
import { CommonModule } from '@angular/common';
import { ProductService } from '../../services/product.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-productaddtemplatedriven',
  imports: [CommonModule,FormsModule],
  templateUrl: './productaddtemplatedriven.component.html',
  styleUrl: './productaddtemplatedriven.component.css'
})
export class ProductaddtemplatedrivenComponent {

  product!:Product;
  productService=inject(ProductService);
  router=inject(Router);
  activatedRoute=inject(ActivatedRoute);
  isEditActive:boolean=false;

  constructor()
  {
    this.product=new Product();

    this.activatedRoute.queryParams.subscribe(data=>{
      let productId=data['pid'];
      if(productId!=null){
        this.isEditActive=true;
        this.productService.getProductById(productId).subscribe({
          next:(resp) => {
            this.product=resp;
          },
          error: (err) => {
            console.log(err);
          }
        })
      }else{
        this.isEditActive=false;
        this.product=new Product();
      }
    })
  }

  saveProduct(f:NgForm)
  {
    if (f.valid) {
      // console.log(this.product);
      // let formJson=JSON.stringify(this.product);
      // alert(formJson);
      this.productService.addProduct(this.product).subscribe({
        next:(res)=>{
          alert('Product Added SuccessFully');
          this.router.navigate(['productlist']);
        },
        error: (err) => {
          console.log('Error', err);
        },
        complete: () => {
          console.log('End of execution');
        }
      })
    }
  }

  
}
