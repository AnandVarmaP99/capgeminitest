import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductaddtemplatedrivenComponent } from './productaddtemplatedriven.component';

describe('ProductaddtemplatedrivenComponent', () => {
  let component: ProductaddtemplatedrivenComponent;
  let fixture: ComponentFixture<ProductaddtemplatedrivenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductaddtemplatedrivenComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductaddtemplatedrivenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
