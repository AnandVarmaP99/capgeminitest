import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductaddmodeldrivenComponent } from './productaddmodeldriven.component';

describe('ProductaddmodeldrivenComponent', () => {
  let component: ProductaddmodeldrivenComponent;
  let fixture: ComponentFixture<ProductaddmodeldrivenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductaddmodeldrivenComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductaddmodeldrivenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
