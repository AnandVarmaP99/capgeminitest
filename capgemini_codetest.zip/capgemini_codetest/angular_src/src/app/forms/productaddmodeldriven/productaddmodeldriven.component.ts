import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Mycustomformvalidators } from '../../custom/mycustomformvalidators';

@Component({
  selector: 'app-productaddmodeldriven',
  imports: [ReactiveFormsModule],
  templateUrl: './productaddmodeldriven.component.html',
  styleUrl: './productaddmodeldriven.component.css'
})
export class ProductaddmodeldrivenComponent {

  productFrm:FormGroup;

  constructor(private fb:FormBuilder)
  {
    this.productFrm=this.fb.group({
      /*  it will check on every key press
      productId:this.fb.control('',[Validators.required])*/
      productId:this.fb.control('',{updateOn:'blur',validators:[Validators.required]}),
      productCode:this.fb.control(''),
      productName:this.fb.control('',[Mycustomformvalidators.productNameValidator]),
      description: this.fb.group({
        shortDesc:this.fb.control(''),
        fullDesc:this.fb.control('')
      }),
      price:this.fb.control(''),
      coupons:this.fb.array([this.fb.control('')])
    });
    //if productcode has 'p' then set validator for price required
    this.productFrm.get('productCode')?.valueChanges.subscribe(data=>{
      console.log(data);
      //get price control
      let priceControl=this.productFrm.get('price');
      //clear price validators if any 
      priceControl?.clearValidators();
      console.log(data.indexOf('P'));
      
      if(data!='' && (data as string).toLowerCase().indexOf('p') == 0)
      {
        priceControl?.setValidators([Validators.required]);
      }

      //update the control with new validator
      priceControl?.updateValueAndValidity();
    });
  }
  
  saveProduct()
  {
    if(this.productFrm.valid)
    {
      let jsonString=JSON.stringify(this.productFrm.value);
      alert('New Product Added'+jsonString);
    }
  }
  validatePattern()
  {
    //get control of the field
    let productCodeCntrl=this.productFrm.get('productCode');
    //add validator to control
    productCodeCntrl?.addValidators(Validators.pattern('^[a-zA-Z0-9 ]+$'));
    //apply the validator on input field for check
    productCodeCntrl?.updateValueAndValidity();
  }
  reset()
  {
    this.productFrm.reset();
    //or to set default values
    // this.productFrm.reset({
    //   productId:'0'  
    // });
  }
  update(){
    this.productFrm.controls['productId'].setValue(1000);

    this.productFrm.patchValue({
      productCode:'testcode',
      productName:'test',
      price:'0'
    })
  }
  get getCodes(){
    return this.productFrm.get('coupons') as FormArray;
  }

  addMore()
  {
    this.getCodes.push(this.fb.control(''));
  }
}
