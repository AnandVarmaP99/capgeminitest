import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NewloggerService {

  private name:string='';
  constructor() {
    console.log('object created');
   }

  setName(nm:string)
  {
    this.name=nm;
    console.log('set Name:'+this.name);
  }
  getName()
  {
    console.log('Name:'+this.name);
  }
}
