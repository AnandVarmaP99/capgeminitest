import { HttpClient, HttpHeaders, JsonpInterceptor } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  httpClient=inject(HttpClient);
  constructor() { }

  getProducts()
  {
    return this.httpClient.get<Product[]>('https://localhost:7157/api/Product/getall');
  }
  addProduct(productToAdd:Product)
  {
    let productJson=JSON.stringify(productToAdd);
    let productHeaders=new HttpHeaders({'Content-Type':'application/json'});
    return this.httpClient.post<boolean>('https://localhost:7157/api/Product/add',productJson,{headers:productHeaders});
  }
  deleteProduct(pid:number)
  {
    return this.httpClient.delete<boolean>(`https://localhost:7157/api/Product/delete/${pid}`);
  }
  getProductById(pid:number)
  {
    return this.httpClient.get<Product>(`https://localhost:7157/api/Product/get/${pid}`);
  }
}
