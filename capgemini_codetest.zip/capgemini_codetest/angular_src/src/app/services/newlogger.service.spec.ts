import { TestBed } from '@angular/core/testing';

import { NewloggerService } from './newlogger.service';

describe('NewloggerService', () => {
  let service: NewloggerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewloggerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
