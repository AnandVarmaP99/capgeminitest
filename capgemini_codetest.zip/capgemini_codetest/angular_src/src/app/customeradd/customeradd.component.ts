import { CommonModule } from '@angular/common';
import { AfterViewChecked, AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CustomerlistComponent } from "../customerlist/customerlist.component";

@Component({
  selector: 'app-customeradd',
  imports: [FormsModule, CommonModule, CustomerlistComponent],
  templateUrl: './customeradd.component.html',
  styleUrl: './customeradd.component.css'
})
export class CustomeraddComponent implements AfterViewInit,AfterViewChecked {
  customerName:string='';
  customerList:string[];

  @ViewChild('custList')
  custListComp!:CustomerlistComponent;

  @ViewChild('divAlert')
  divAlert!:ElementRef;

  constructor()
  {
    this.customerList=[];
  }

  addCustomer()
  {
    this.customerList.push(this.customerName);
    this.custListComp.customerFromViewChild.push(this.customerName);

    this.divAlert.nativeElement.style.display='block';
    this.divAlert.nativeElement.innerText='New Customer Added';

    setTimeout(() => {
      this.divAlert.nativeElement.style.display='none';
      this.divAlert.nativeElement.innerText='';
    }, 2000);
  }

  readData(msg:string)
  {
    this.customerName=msg;
  }
  ngAfterViewChecked(): void {
    
  }
  ngAfterViewInit(): void {
    
  }
}
