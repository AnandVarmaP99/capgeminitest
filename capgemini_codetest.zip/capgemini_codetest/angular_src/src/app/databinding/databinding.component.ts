import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-databinding',
  imports: [FormsModule],
  templateUrl: './databinding.component.html',
  styleUrl: './databinding.component.css',
})
export class DatabindingComponent {
  num:number=100;
  productname:string='';
  id:number=0;

  activatedRoute=inject(ActivatedRoute);
  constructor()
  {
    this.activatedRoute.params.subscribe(data=>
      this.id=data['id']
    )
  }

  showAlert():void
  {
    alert('clicked');
  }
}

