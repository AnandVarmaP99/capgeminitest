import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Product } from '../models/product';
import { MycustomDirective } from '../custom/mycustom.directive';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-directivessample',
  imports: [FormsModule,CommonModule,MycustomDirective],
  templateUrl: './directivessample.component.html',
  styleUrl: './directivessample.component.css'
})
export class DirectivessampleComponent {
  
  activatedRoute=inject(ActivatedRoute);
  checknum:number=0;
  colors:string[];
  selectedcolor:string='';
  products:Product[];
  fullName:string='';

  constructor()
  {
    this.colors=['red','green','blue'];
    this.products=[];

    let p1=new Product(101,'Gold drop','GR201',100);
    let p2=new Product(105,'Safola','SF301',200);
    let p3=new Product(102,'AS Brand','ASB801',500);
    let p4=new Product(108,'Ghee','G999',100);

    this.products.push(p1);
    this.products.push(p2);
    this.products.push(p3);
    this.products.push(p4);

    this.activatedRoute.queryParams.subscribe(data =>
    {
      this.fullName=data['firstName']+' '+data['lastName']
    })
  }

}
