import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectivessampleComponent } from './directivessample.component';

describe('DirectivessampleComponent', () => {
  let component: DirectivessampleComponent;
  let fixture: ComponentFixture<DirectivessampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DirectivessampleComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DirectivessampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
