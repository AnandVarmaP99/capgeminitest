import { AbstractControl } from "@angular/forms";

export class Mycustomformvalidators {
    static productNameValidator(ctrl:AbstractControl){
        const val=ctrl.value as string;

        if(val!=null && val.includes('@'))
        {
            return{codeerror:true};
        }
        return null;
    }
}
