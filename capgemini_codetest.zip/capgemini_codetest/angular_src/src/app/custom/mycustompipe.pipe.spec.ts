import { MycustompipePipe } from './mycustompipe.pipe';

describe('MycustompipePipe', () => {
  it('create an instance', () => {
    const pipe = new MycustompipePipe();
    expect(pipe).toBeTruthy();
  });
});
