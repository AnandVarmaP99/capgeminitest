import { Mycustomformvalidators } from './mycustomformvalidators';

describe('Mycustomformvalidators', () => {
  it('should create an instance', () => {
    expect(new Mycustomformvalidators()).toBeTruthy();
  });
});
