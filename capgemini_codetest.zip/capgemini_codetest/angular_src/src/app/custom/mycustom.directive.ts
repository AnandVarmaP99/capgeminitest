import { Directive,ElementRef,HostListener, inject, Input } from '@angular/core';

@Directive({
  selector: '[appMycustom]'
})
export class MycustomDirective {

  ele = inject(ElementRef);
  //constructor(private ele:ElementRef)
  /*
  if input field ref is same as select name then - @Input('appMycustom')*/
   //if different below 
  @Input('myColor')
  color!: string;

  constructor()
  {
    this.ele.nativeElement.style.color ='red';
  }


@HostListener('mouseover')
  onMouseOver() {
    if(this.color!=null && this.color!='' && this.color!=undefined)
    {
      this.ele.nativeElement.style.color=this.color ;//= 'green';
    }else{
      this.ele.nativeElement.style.color= 'green';
    }
  }

  @HostListener('mouseout')
  onMouseOutCall() {
    this.ele.nativeElement.style.color = 'black';
  }

  @HostListener('click')
  OnClick() {
    alert('Clicked');
  }
}
