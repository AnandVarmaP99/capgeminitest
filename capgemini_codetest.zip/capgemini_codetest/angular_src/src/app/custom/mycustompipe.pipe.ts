import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mycustompipe'
})
export class MycustompipePipe implements PipeTransform {

  /*   same line work for sample 1 & 2
  transform(value: unknown, ...args: unknown[]): unknown {*/
  transform(value: string[], ...args: string[]): string[] {
   /*     reading value  sample -1 
    let val:string=value as string;
    let newValue=val.toString().padStart(10,'X');
    return newValue;
    */
     /*    reading args    sample -2
      let val:string=value as string;
      let prefix:string=args[0] as string;
      let fillChar:string=args[1] as string;
      let newValue=val.toString().padStart(10,fillChar);
      return prefix+newValue;*/

      let searchname=args[0];
      let names=value.filter(x=>x.includes(searchname));
      return names;

  }

}
