import { MycustomDirective } from './mycustom.directive';

describe('MycustomDirective', () => {
  it('should create an instance', () => {
    const directive = new MycustomDirective();
    expect(directive).toBeTruthy();
  });
});
