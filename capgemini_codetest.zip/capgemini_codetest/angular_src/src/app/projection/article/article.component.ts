import { AfterContentChecked, AfterContentInit, Component, ContentChild, ElementRef, inject, OnInit } from '@angular/core';
import { LoggerService } from '../../services/logger.service';

@Component({
  selector: 'app-article',
  imports: [],
  templateUrl: './article.component.html',
  styleUrl: './article.component.css'
})
export class ArticleComponent implements OnInit,AfterContentChecked,AfterContentInit{
  @ContentChild('footer')
  footerContent!:ElementRef;
  loggerService=inject(LoggerService);
  constructor()
  {
    this.loggerService.getName();
  }

  ngOnInit(): void {
    
  }
  ngAfterContentChecked(): void {
    console.log('AfterContentChecked triggered');
  }
  ngAfterContentInit(): void {
    console.log('AfterContentInit triggered');
    this.footerContent.nativeElement.innerText=this.footerContent.nativeElement.innerText +' (Mentor)';
  }

}
