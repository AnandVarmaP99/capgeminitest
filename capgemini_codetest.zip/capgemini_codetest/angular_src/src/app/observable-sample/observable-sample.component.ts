import { Component, ElementRef, ViewChild } from '@angular/core';
import { count, delay, filter, map, Observable, retry, skip, Subscription, take, timeInterval } from 'rxjs';

@Component({
  selector: 'app-observable-sample',
  imports: [],
  templateUrl: './observable-sample.component.html',
  styleUrl: './observable-sample.component.css'
})
export class ObservableSampleComponent {
  observableData!:Observable<string>;
  subscription!:Subscription;

  @ViewChild('subscribeOutput')
  subscribeOutput!:ElementRef;
  @ViewChild('error')
  errorOnObservable!:ElementRef;
  @ViewChild('completeObservable')
  completeOnObservable!:ElementRef;

  createObservable()
  {
    this.observableData=new Observable<string>(ob=>{
      ob.next('Test1');
      ob.next('Test2');
      ob.next('Test3');

      setInterval(() => {
        ob.next('Anand'+Math.random());
      }, 1000);

      setTimeout(() => {
        ob.complete();
      }, 5000);
      /* for error generate and retry */
      // setTimeout(() => {
      //   ob.error('oops something went wrong');
      // }, 3000);
      
    })
  }
  operate()
  {
    this.observableData=this.observableData.pipe(
      map(c=>c.toLocaleUpperCase()),
      skip(1),
      take(5),
      filter(c=>c.startsWith('ANAND')),
      retry(2) //retry({count:2,delay:2000})
    );
  }
  subscribeObservable()
  {
    let ob={
      next:(resp:any)=>{
        let innerText=this.subscribeOutput.nativeElement.innerText as string;
        this.subscribeOutput.nativeElement.innerText=innerText+((innerText!=null && innerText!='')?'\n':'')+resp;
        //console.log(resp);
      },
      error:(err:any)=>{
        let innerText=this.errorOnObservable.nativeElement.innerText as string;
        this.errorOnObservable.nativeElement.innerText=innerText+((innerText!=null && innerText!='')?'\n':'')+err;
        //console.log(err);
      },
      complete:() =>{
        this.completeOnObservable.nativeElement.innerText='End of Execution';
        //console.log('End of Execution');
      }
    }
    //this.observableData.subscribe(ob);
    this.subscription=this.observableData.subscribe(ob); //for unsubscribe
  }
  unsubscribeObservable()
  {
    this.subscription.unsubscribe();
    let innerText=this.subscribeOutput.nativeElement.innerText as string;
    this.subscribeOutput.nativeElement.innerText=innerText+'\n unsubscribed';
  }
}
