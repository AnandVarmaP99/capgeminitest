import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { LoggerService } from './services/logger.service';
import { NewloggerService } from './services/newlogger.service';
import { HttpClient, provideHttpClient } from '@angular/common/http';

export const appConfig: ApplicationConfig = {
  providers: [provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(routes),
    //{provide:LoggerService}       
    {provide:LoggerService,useClass:NewloggerService},   //replacing current with newloggerservice
    provideHttpClient()
  ]
};
