import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FirstsampleComponent } from "./firstsample/firstsample.component";
import { DatabindingComponent } from './databinding/databinding.component';
import { DirectivessampleComponent } from './directivessample/directivessample.component';
import { PipeComponent } from "./pipe/pipe.component";
import { NavbarComponent } from "./navbar/navbar.component";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, NavbarComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'myapp';
}
