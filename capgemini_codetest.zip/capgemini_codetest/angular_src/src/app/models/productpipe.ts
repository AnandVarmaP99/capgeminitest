export class Productpipe {
    productcode:string|undefined;
    productname:string|undefined;
    description:string|undefined;
    price:string|undefined;
    
    constructor(pcode?:string,pname?:string,desc?:string,price?:string)
    {
        this.productcode=pcode;
        this.productname=pname;
        this.description=desc;
        this.price=price;
    }
}
