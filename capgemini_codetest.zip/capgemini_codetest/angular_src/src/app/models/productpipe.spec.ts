import { Productpipe } from './productpipe';

describe('Productpipe', () => {
  it('should create an instance', () => {
    expect(new Productpipe()).toBeTruthy();
  });
});
