export class Product {
    productId:number|undefined;
    productName:string|undefined;
    productCode:string|undefined;
    price:number|undefined;

    constructor();
    constructor(pid:number,pname:string,pcode:string,price:number);

    constructor(pid?:number,pname?:string,pcode?:string,price?:number)
    {
        this.productId=pid;
        this.productName=pname;
        this.productCode=pcode;
        this.price=price;
    }
}
