import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-customerlist',
  imports: [],
  templateUrl: './customerlist.component.html',
  styleUrl: './customerlist.component.css'
})
export class CustomerlistComponent {
  
  @Input('custList')
  customers:string[];

  @Output('on-select')
  onSelect!:EventEmitter<string>;
  customerFromViewChild: string[];

  constructor()
  {
    this.customers=[];
    this.customerFromViewChild=[];
    this.onSelect=new EventEmitter<string>();
  }

  selectCustomer(customer:string)
  {
    this.onSelect.emit(customer);
  }
}