import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoggerService } from '../services/logger.service';

@Component({
  selector: 'app-firstsample',
  imports: [],
  templateUrl: './firstsample.component.html',
  styleUrl: './firstsample.component.css',
  providers:[LoggerService]
})
export class FirstsampleComponent {
  id:number=0;
  activatedRoute=inject(ActivatedRoute);

  loggerService=inject(LoggerService);

  constructor()
  {
    this.activatedRoute.params.subscribe(data=>
      this.id= data['id']
    )

    this.loggerService.setName('pradeep');
    this.loggerService.getName();
  }
}
