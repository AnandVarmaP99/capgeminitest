import { Component, inject } from '@angular/core';
import { Product } from '../models/product';
import { Productpipe } from '../models/productpipe';
import { CommonModule } from '@angular/common';
import { MycustompipePipe } from '../custom/mycustompipe.pipe';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { LoggerService } from '../services/logger.service';

@Component({
  selector: 'app-pipe',
  imports: [CommonModule, MycustompipePipe, FormsModule],
  templateUrl: './pipe.component.html',
  styleUrl: './pipe.component.css'
})
export class PipeComponent {
  productList:Productpipe[];
  builtInPipes:string[]=['uppercase','lowercase','date','number','currency','percent','json','keyvalue'
    ,'slice','titlecase','async','I18nplural','I18nselect'  ];
  date:Date=new Date('1996-03-12');
  names:string[]=['Anand Varma','Balaram','Bhavana','Rama Devi','Ashish Saini','Jayavardhan'];
  searchName:string='';
  id:number=0;
  activatedRoute=inject(ActivatedRoute);

  loggerService=inject(LoggerService);

  constructor()
  {
    this.productList=[];
    let p1=new Productpipe('101','Lenovo G50','Server','35000');
    let p2=new Productpipe('105','Dell','Professional','45000');
    let p3=new Productpipe('110','Asus','Professional','54000');
    let p4=new Productpipe('120','Acer','Professional','30000');

    this.productList.push(p1);
    this.productList.push(p2);
    this.productList.push(p3);
    this.productList.push(p4);

    this.activatedRoute.params.subscribe(data=>
      this.id=data['newid']
    )

    this.loggerService.setName('Anand');
    this.loggerService.getName();
  }

  
}
