import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-childpipe',
  imports: [RouterOutlet,RouterLink],
  templateUrl: './childpipe.component.html',
  styleUrl: './childpipe.component.css'
})
export class ChildpipeComponent {
  router=inject(Router);
  redirect()
  {
    this.router.navigate(['childpipe',150,{newid:101}],{
      queryParams:{
        firstName:'Anand',
        lastName:'Varma'
      }
    });
  }
}
