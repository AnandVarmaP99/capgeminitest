import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildpipeComponent } from './childpipe.component';

describe('ChildpipeComponent', () => {
  let component: ChildpipeComponent;
  let fixture: ComponentFixture<ChildpipeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ChildpipeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChildpipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
