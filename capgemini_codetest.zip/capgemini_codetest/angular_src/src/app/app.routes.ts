import { RouterLink, Routes } from '@angular/router';
import { FirstsampleComponent } from './firstsample/firstsample.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { DirectivessampleComponent } from './directivessample/directivessample.component';
import { PipeComponent } from './pipe/pipe.component';
import { ChildpipeComponent } from './pipe/childpipe/childpipe.component';
import { PersonalComponent } from './pipe/childpipe/personal/personal.component';
import { CustomeraddComponent } from './customeradd/customeradd.component';
import { ProductaddtemplatedrivenComponent } from './forms/productaddtemplatedriven/productaddtemplatedriven.component';
import { ProductaddmodeldrivenComponent } from './forms/productaddmodeldriven/productaddmodeldriven.component';
import { ProjectionComponent } from './projection/projection.component';
import { ObservableSampleComponent } from './observable-sample/observable-sample.component';
import { ProductListComponent } from './forms/product-list/product-list.component';

export const routes: Routes = [
    {path:'home/id:',component:FirstsampleComponent},
    {path:'databinding/:id',component:DatabindingComponent},
    {path:'directive',component:DirectivessampleComponent},
    {path:'pipes',component:PipeComponent},
    {path:'childpipe',component:ChildpipeComponent,children:[
        {path:'personal',component:PersonalComponent}
    ]},
    {path:'student',loadComponent:()=>import('../app/student/student.component').then(c=>c.StudentComponent)},
    {path:'data sharing',component:CustomeraddComponent},
    {path:'templatedrivenform',component:ProductaddtemplatedrivenComponent},
    {path:'modeldrivenform',component:ProductaddmodeldrivenComponent},
    {path:'contentprojection',component:ProjectionComponent},
    {path:'observable',component:ObservableSampleComponent},
    {path:'productlist',component:ProductListComponent},
    {path:'**',component:FirstsampleComponent},
];
